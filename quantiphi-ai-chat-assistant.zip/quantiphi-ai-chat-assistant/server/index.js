require("dotenv").config();
const express = require("express");
const cors = require("cors");
const OpenAI = require("openai");
const connectDatabase = require("./db");
const Conversation = require("./models/Conversation");

const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5173" }));
app.use(express.json({ limit: "1mb" }));

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "missing-key" });
const TONES = {
  Professional: "Use a clear, professional, structured tone.",
  Casual: "Use a friendly, natural, conversational tone.",
  Concise: "Be brief and direct. Prefer short answers and bullets when useful."
};
const hasDb = () => Boolean(process.env.MONGODB_URI);

app.get("/api/health", (_req, res) => res.json({
  status: "ok", database: hasDb() ? "configured" : "not-configured",
  ai: process.env.OPENAI_API_KEY ? "configured" : "missing-api-key"
}));

app.get("/api/conversations", async (_req, res, next) => {
  try {
    if (!hasDb()) return res.json([]);
    const items = await Conversation.find({}, "title tone updatedAt")
      .sort({ updatedAt: -1 }).limit(100).lean();
    res.json(items);
  } catch (e) { next(e); }
});

app.post("/api/conversations", async (req, res, next) => {
  try {
    if (!hasDb()) return res.status(503).json({ error: "Configure MongoDB to save conversations." });
    const item = await Conversation.create({ title: req.body.title || "New conversation" });
    res.status(201).json(item);
  } catch (e) { next(e); }
});

app.get("/api/conversations/:id", async (req, res, next) => {
  try {
    if (!hasDb()) return res.status(503).json({ error: "Configure MongoDB to load conversations." });
    const item = await Conversation.findById(req.params.id);
    if (!item) return res.status(404).json({ error: "Conversation not found." });
    res.json(item);
  } catch (e) { next(e); }
});

app.delete("/api/conversations/:id", async (req, res, next) => {
  try {
    if (!hasDb()) return res.status(503).json({ error: "Configure MongoDB to delete conversations." });
    await Conversation.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (e) { next(e); }
});

app.patch("/api/conversations/:id/tone", async (req, res, next) => {
  try {
    const { tone } = req.body;
    if (!TONES[tone]) return res.status(400).json({ error: "Invalid tone." });
    const item = await Conversation.findByIdAndUpdate(req.params.id, { tone }, { new: true });
    if (!item) return res.status(404).json({ error: "Conversation not found." });
    res.json(item);
  } catch (e) { next(e); }
});

app.post("/api/chat/stream", async (req, res) => {
  const { conversationId, message, tone = "Professional", regenerate = false } = req.body;
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "Add OPENAI_API_KEY to your .env file." });
  if (!TONES[tone]) return res.status(400).json({ error: "Invalid response tone." });
  if (!message || typeof message !== "string" || message.length > 12000) {
    return res.status(400).json({ error: "Enter a message (maximum 12,000 characters)." });
  }

  let conversation;
  try {
    if (hasDb()) {
      conversation = await Conversation.findById(conversationId);
      if (!conversation) return res.status(404).json({ error: "Conversation not found." });
      conversation.tone = tone;
      if (!regenerate) {
        conversation.messages.push({ role: "user", content: message });
        if (conversation.messages.length === 1) conversation.title = message.slice(0, 55);
      }
      await conversation.save();
    }

    const history = conversation ? conversation.messages.slice(0, regenerate ? -1 : undefined) : [];
    const apiMessages = [
      { role: "system", content: `You are Nova, a helpful AI assistant. ${TONES[tone]} Be accurate and explain uncertainty.` },
      ...history.slice(-30).map(m => ({ role: m.role, content: m.content })),
      ...(conversation ? [] : [{ role: "user", content: message }])
    ];
    const stream = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: apiMessages,
      stream: true,
      temperature: tone === "Concise" ? 0.4 : 0.7
    });

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders?.();

    let answer = "";
    for await (const chunk of stream) {
      const token = chunk.choices?.[0]?.delta?.content || "";
      if (token) {
        answer += token;
        res.write(`data: ${JSON.stringify({ token })}\n\n`);
      }
    }
    if (conversation && answer) {
      conversation.messages.push({ role: "assistant", content: answer });
      await conversation.save();
    }
    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (error) {
    console.error("Chat stream error:", error.message);
    if (!res.headersSent) return res.status(500).json({ error: "Unable to generate a response. Check your API key and server logs." });
    res.write(`data: ${JSON.stringify({ error: "The response was interrupted. Please try again." })}\n\n`);
    res.end();
  }
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Unexpected server error." });
});

const port = process.env.PORT || 5000;
connectDatabase().then(() => app.listen(port, () => console.log(`API running on http://localhost:${port}`)))
  .catch(() => process.exit(1));