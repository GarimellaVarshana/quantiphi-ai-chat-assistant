const mongoose = require("mongoose");

const MessageSchema = new mongoose.Schema({
  role: { type: String, enum: ["user", "assistant"], required: true },
  content: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
}, { _id: true });

const ConversationSchema = new mongoose.Schema({
  title: { type: String, default: "New conversation", maxlength: 100 },
  tone: { type: String, enum: ["Professional", "Casual", "Concise"], default: "Professional" },
  messages: { type: [MessageSchema], default: [] }
}, { timestamps: true });

module.exports = mongoose.model("Conversation", ConversationSchema);