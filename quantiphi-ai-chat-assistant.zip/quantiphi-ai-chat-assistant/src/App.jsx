import React, { useEffect, useRef, useState } from "react";

const API = "/api";
const starter = [
  { role: "assistant", content: "Hi! I'm Nova, your AI assistant. Ask me anything, brainstorm an idea, or get help with a task." }
];

export default function App() {
  const [conversations, setConversations] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [messages, setMessages] = useState(starter);
  const [tone, setTone] = useState("Professional");
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState("");
  const bottomRef = useRef(null);
  const abortRef = useRef(null);

  const refreshList = async () => {
    try {
      const r = await fetch(`${API}/conversations`);
      if (r.ok) setConversations(await r.json());
    } catch { setNotice("Cannot reach the server. Start the backend and try again."); }
  };
  useEffect(() => { refreshList(); }, []);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const newChat = () => {
    abortRef.current?.abort();
    setActiveId(null); setMessages(starter); setTone("Professional");
    setInput(""); setNotice("");
  };

  const openChat = async (id) => {
    if (loading) return;
    try {
      const r = await fetch(`${API}/conversations/${id}`);
      const data = await r.json();
      if (!r.ok) throw new Error(data.error);
      setActiveId(id); setMessages(data.messages?.length ? data.messages : starter);
      setTone(data.tone || "Professional"); setNotice("");
    } catch (e) { setNotice(e.message); }
  };

  const removeChat = async (id, event) => {
    event.stopPropagation();
    if (!window.confirm("Delete this conversation permanently?")) return;
    const r = await fetch(`${API}/conversations/${id}`, { method: "DELETE" });
    if (r.ok) {
      if (activeId === id) newChat();
      refreshList();
    }
  };

  const send = async (overrideText, isRegenerate = false) => {
    const text = (overrideText ?? input).trim();
    if ((!text && !isRegenerate) || loading) return;
    setNotice("");
    let id = activeId;
    try {
      if (!id) {
        const created = await fetch(`${API}/conversations`, {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: text.slice(0, 55) || "New conversation" })
        });
        const data = await created.json();
        if (!created.ok) throw new Error(data.error || "Could not create conversation. Configure MongoDB.");
        id = data._id; setActiveId(id);
      }
      const userText = isRegenerate ? [...messages].reverse().find(m => m.role === "user")?.content : text;
      if (!userText) return;
      if (isRegenerate) {
        setMessages(prev => prev.slice(0, -1));
      } else {
        setMessages(prev => [...prev, { role: "user", content: text }, { role: "assistant", content: "" }]);
        setInput("");
      }
      setMessages(prev => isRegenerate ? [...prev, { role: "assistant", content: "" }] : prev);
      setLoading(true);
      const controller = new AbortController(); abortRef.current = controller;
      const response = await fetch(`${API}/chat/stream`, {
        method: "POST", signal: controller.signal,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId: id, message: userText, tone, regenerate: isRegenerate })
      });
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Request failed.");
      }
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split("\n\n"); buffer = events.pop() || "";
        for (const event of events) {
          const line = event.split("\n").find(x => x.startsWith("data: "));
          if (!line) continue;
          const payload = JSON.parse(line.slice(6));
          if (payload.token) setMessages(prev => {
            const copy = [...prev]; const last = copy.length - 1;
            copy[last] = { ...copy[last], content: copy[last].content + payload.token };
            return copy;
          });
          if (payload.error) setNotice(payload.error);
        }
      }
      refreshList();
    } catch (e) {
      if (e.name !== "AbortError") setNotice(e.message);
      setMessages(prev => prev.filter((m, i) => !(i === prev.length - 1 && m.role === "assistant" && !m.content)));
    } finally { setLoading(false); }
  };

  const changeTone = async (value) => {
    setTone(value);
    if (activeId) await fetch(`${API}/conversations/${activeId}/tone`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ tone: value })
    });
  };

  const exportChat = () => {
    const body = messages.map(m => `${m.role === "user" ? "You" : "Nova"}:\n${m.content}`).join("\n\n");
    const blob = new Blob([body], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "nova-conversation.txt"; a.click();
    URL.revokeObjectURL(url);
  };

  const lastUserMessage = [...messages].reverse().find(m => m.role === "user");
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">✦</div><div><strong>nova</strong><span>AI ASSISTANT</span></div></div>
      <button className="new-chat" onClick={newChat}><span>＋</span> New chat</button>
      <div className="side-label">YOUR CHATS</div>
      <div className="history">
        {conversations.map(c => <div key={c._id} className={`history-item ${activeId === c._id ? "active" : ""}`} onClick={() => openChat(c._id)}>
          <span className="chat-icon">▤</span><span className="history-title">{c.title || "New conversation"}</span>
          <button className="delete-chat" title="Delete conversation" onClick={e => removeChat(c._id, e)}>×</button>
        </div>)}
        {!conversations.length && <p className="empty-history">Your saved conversations will appear here.</p>}
      </div>
      <div className="sidebar-bottom"><div className="avatar">N</div><div><strong>Nova Assistant</strong><span>AI workspace</span></div><span className="online-dot"/></div>
    </aside>

    <main className="main">
      <header className="topbar">
        <div><span className="mobile-brand">✦ nova</span><span className="workspace-label">Workspace</span><span className="crumb"> / AI Chat</span></div>
        <div className="top-actions"><span className="status-dot"/> <span className="status-text">AI assistant</span><button className="export-btn" onClick={exportChat} disabled={messages.length <= 1}>↥ Export</button></div>
      </header>

      <section className="chat-area">
        {messages.length <= 1 && <div className="welcome">
          <div className="welcome-icon">✦</div>
          <div className="eyebrow">YOUR AI WORKSPACE</div>
          <h1>How can I help<br/><em>you today?</em></h1>
          <p>Ask questions, explore ideas, or get help with your work.</p>
          <div className="suggestions">
            {["Explain machine learning simply","Help me prepare for a technical interview","Write a professional email"].map((s, i) =>
              <button key={s} onClick={() => send(s)} disabled={loading}><span>{["✧", "⌘", "↗"][i]}</span>{s}<b>↗</b></button>)}
          </div>
        </div>}
        <div className="messages">
          {messages.map((m, i) => <div className={`message-row ${m.role}`} key={i}>
            {m.role === "assistant" && <div className="message-avatar">✦</div>}
            <div className="message-content">
              <div className="message-author">{m.role === "user" ? "You" : "Nova"} <span>{m.role === "assistant" ? "AI ASSISTANT" : ""}</span></div>
              <div className={`bubble ${m.role}`}>{m.content || (loading ? <span className="typing"><i/><i/><i/></span> : "")}</div>
              {m.role === "assistant" && m.content && i === messages.length - 1 && !loading &&
                <div className="message-tools"><button onClick={() => navigator.clipboard?.writeText(m.content)}>Copy</button><button onClick={() => send(lastUserMessage?.content, true)}>↻ Regenerate</button></div>}
            </div>
          </div>)}
          <div ref={bottomRef}/>
        </div>
      </section>

      <footer className="composer-wrap">
        {notice && <div className="notice">{notice}</div>}
        <div className="composer">
          <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => {
            if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
          }} placeholder="Message Nova..." rows="1" disabled={loading}/>
          <div className="composer-bottom">
            <div className="tone-control"><span>✧</span><label htmlFor="tone">Tone</label>
              <select id="tone" value={tone} onChange={e => changeTone(e.target.value)}>
                <option>Professional</option><option>Casual</option><option>Concise</option>
              </select>
            </div>
            <div className="send-side"><span className="hint">↵ Send · Shift + ↵ New line</span>
              <button className="send-btn" onClick={() => send()} disabled={loading || !input.trim()}>{loading ? "…" : "↑"}</button>
            </div>
          </div>
        </div>
        <p className="disclaimer">Nova can make mistakes. Verify important information.</p>
      </footer>
    </main>
  </div>;
}